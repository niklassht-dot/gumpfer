# Café Gumpfer – Website-Entwurf mit Unterseiten

Statische Seite (HTML/CSS/JS, kein WordPress).

## Lokal starten
```
cd ~/Arbeit/Entwürfe/gumpfer-entwurf && P=$(python3 -c 'import socket;s=socket.socket();s.bind(("",0));print(s.getsockname()[1])') && { (sleep 1; open http://localhost:$P) & python3 -m http.server $P; }
```

## Seiten
- index.html – Startseite
- cafe-stralsund.html – Café am Ozeaneum mit Speisekarte
- cafe-sassnitz.html – Café an der Mole
- torten.html – Tortenbestellung
- hochzeitstorten.html – Galerie
- kontakt.html – Kontakt & Gutschein

## Medien
Bilder von der bestehenden Website, remote eingebunden – nichts lokal gespeichert.

## Offene Punkte
- Hero-Videos: 6 Stockclips von Pexels (Tortenstück, Latte Art, Großsegler, Gebäckvitrine, Sahnetorte einstreichen/verzieren) – Links über die Pexels-Seiten ermittelt, wegen getrennter Mac-Verbindung nicht im Browser abgespielt
- Alle übrigen Fotos von gumpfer.de (Uploads von 2019) – Auflösung nicht geprüft
- Preise: Speisekarte 2026 (PDF), Torten laut Online-Shop
- Sassnitz: Adresse/Telefon nur aus Verzeichnissen (Am Fuß der Mole, 038392 649888) – bestätigen lassen
- Kartenzahlung im Café widersprüchlich (Yelp ja, andere Quellen nein) – nicht erwähnt
- Bewertungen: kurze echte Zitate von Tripadvisor, Restaurant Guru, speisekarte.menu
